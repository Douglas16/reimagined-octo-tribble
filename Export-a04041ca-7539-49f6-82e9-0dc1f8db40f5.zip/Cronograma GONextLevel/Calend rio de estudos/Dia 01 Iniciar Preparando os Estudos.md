# Dia 01 - Iniciar Preparando os Estudos

Data: Mar 31, 2020
Hora de início: 08:00
Hora de término: 10:00
Status: Iniciado

Iniciar os videos do "Preparando os Estudos"

Hoje será um dia que eu irei focar totalmente nas dicas do Diego quanto a importância de se preparar e organizar suas tarefas diárias.

### Bootcamp GoStack

- [ ]  Preparar os Estudos
- [ ]  Ambiente de Desenvolvimento
- [ ]  Desafio Organizando seus Estudos