# Dia 04 - O foguete continua subindo 🚀

Data: Apr 02, 2020
Hora de início: 19:00
Hora de término: 21:00
Status: Pendente

Hoje não é um dia menos especial que os anteriores! 

Hoje continuarei na minha evolução como programador lendo um conteúdo incrível postado no blog da rocketseat, e ouvir um podcast que irá me ajudar a me destacar no mercado de trabalho.

### Conteúdo para leitura

- [ ]  [As melhores features do ES6, ES7 e ES8](https://blog.rocketseat.com.br/as-melhores-features-do-es6-es7-e-es8/)

### Ainda não me sinto seguro com ES6?

- [ ]  Assistir o curso `Javascript ES6+` do [STARTER](https://rocketseat.com.br/starter) da rocketseat

### Conteúdo extra

- [ ]  Ouvir o podcast `Como se destacar na carreira? Dicas e técnicas | Podcast FalaDev #19` no canal da Rocketseat do youtube