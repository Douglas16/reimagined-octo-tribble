# Dia 06 - Dia de prática!

Data: Apr 04, 2020
Status: Pendente

Hoje é meu primeiro dia de prática, caso eu já tenha assistido algum conteúdo sobre programação, irei tentar desenvolver algo novo.

### Ideias de desenvolvimento

- [ ]  Desenhar o layout do meu futuro portfólio, posso usar lápis e papel, ou mesmo softwares como o Figma e Sketch.
- [ ]  Desenvolver uma calculadora com JavaScript, onde posso inserir dois valores e uma escolher operação.