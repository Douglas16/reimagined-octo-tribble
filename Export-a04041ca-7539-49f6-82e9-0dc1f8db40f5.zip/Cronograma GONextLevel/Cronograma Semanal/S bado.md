# Sábado

Hora de início: 08:30
Hora de término: 10:30