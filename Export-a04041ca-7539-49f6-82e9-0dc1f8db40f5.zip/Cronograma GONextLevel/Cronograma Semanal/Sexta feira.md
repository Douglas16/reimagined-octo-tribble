# Sexta-feira

Hora de início: 20:00
Hora de término: 22:00